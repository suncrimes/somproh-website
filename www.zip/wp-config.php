<?php
//Begin Really Simple Security session cookie settings
@ini_set('session.cookie_httponly', true);
@ini_set('session.cookie_secure', true);
@ini_set('session.use_only_cookies', true);
//END Really Simple Security cookie settings
//Begin Really Simple Security key
define('RSSSL_KEY', '1ajppL8TtedY4RviZLOXM9d1LF6ZerSytKZaovmllNdiOyVXSgZslMSZ1VJEQT4f');
//END Really Simple Security key

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'cttzcg189_somproh' );

/** Database username */
define( 'DB_USER', 'cttzcg189_somproh' );

/** Database password */
define( 'DB_PASSWORD', '!Goku92191576databas' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '[wl<wupsb][Jj..SEvFx]6 upV}Ueq`5R~eoT&UJ59X<tm|+5fWCN~a/g3;>_SZ0' );
define( 'SECURE_AUTH_KEY',  'Z)qbiKgX`Cb0V}vv/`$u42!Mf;[dj!F.y@duMJ,3~zGqq:&`E{m(Q(!sRCqeT>8i' );
define( 'LOGGED_IN_KEY',    '09.nb[sB:|$y6:f!(r@L{gv=w:%Ysga?!3aajmkv}HY@cA{GK|V]3F{kqcJN#tX4' );
define( 'NONCE_KEY',        'Or?@EzJu<q$>n~-RW_a+c2nZgKp<S +@*{&wA.4[)^a(p,^U^YJ,md*L~i0$b/9|' );
define( 'AUTH_SALT',        'e{zVzOI8GM[_@lMbE0~|9m8E)OcNt%!e ]2oS.Z#sh y6fuLUt?i1PPW:k4NRA|o' );
define( 'SECURE_AUTH_SALT', 'B$bDH$-S)2eLnlj8WUegHkdf^SVFNN-V6i%H-}x{is(S-$T+LZChv$j:8qHBQu}k' );
define( 'LOGGED_IN_SALT',   'j(oQ+j%[4?EFSB)`JEQ:aj<6LIB%pC&n|n(n${# w}uT=_!fB6OY=qD${(RkfkM/' );
define( 'NONCE_SALT',       'AU4Yv@ jn89+|j9Ssl5CV$6C6{zDRLnx.-FJx,a7D~Fyi<B$k1QOxIr-+gV|iVX/' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_somproh';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
